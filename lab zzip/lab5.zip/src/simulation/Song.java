package simulation;

/**
 * Creates an instance of a song
 *
 * @author Ethan Chen
 */

public class Song implements Comparable<Song> {
    private String artist;
    private String title;

    /**
     * creates a new song class
     *
     * @param artist name of the artist
     * @param title title of the song
     */
    public Song(String artist, String title) {
        this.artist = artist;
        this.title = title;
    }

    /**
     * gets the artist name
     *
     * @return artist name
     */
    public String getArtist() {
        return this.artist;
    }

    /**
     * gets the song title
     * @return song title
     */
    public String getTitle() {
        return this.title;
    }

    /**
     * overrides the original to string function
     *
     * @return a string in the desired format
     */
    @Override
    public String toString() {
        return "Artist: " + this.artist +
                ", Title: " + this.title;
    }

    /**
     * compares songs
     *
     * @param s an object you want to compare
     * @return t/f depending on what was passed in
     */
    @Override
    public boolean equals(Object s) {
        if (s instanceof Song) {
            Song song = (Song) s;
            return song.artist.equals(this.artist) && song.title.equals(this.title);
        }
        return false;
    }

    /**
     * custom hash function for hash codes
     *
     * @return hash code made with the desired math
     */
    @Override
    public int hashCode() {
        return this.artist.hashCode() + this.title.hashCode();
    }

    /**
     * for sorting songs
     *
     * @param s the object to be compared.
     * @return int -1, 0, or 1
     */
    @Override
    public int compareTo(Song s) {
        int x = this.artist.compareTo(s.artist);
        if (x == 0) {
            x = this.title.compareTo(s.title);
        }
        return x;
    }
}
