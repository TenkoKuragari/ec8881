package simulation;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import static java.lang.Math.ceil;

/**
 * Arnolds class that makes the jukebox and runs the simulations
 *
 * @author Ethan Chen
 */

public class Arnolds {
    public HashMap<Song, Integer> jukebox = new HashMap<>();
    private final static int RANDOM_SEED = 42;
    private static final Random rng = new Random(RANDOM_SEED);
    public final int MAX_RUNS = 200000;

    /**
     * creates a new Arnolds class
     *
     * @param filename name of the song file
     * @throws FileNotFoundException if file can't be found
     */
    public Arnolds(String filename) throws FileNotFoundException {
        System.out.println("Loading the jukebox with songs:");
        Scanner jim = new Scanner(new File(filename));

/*
-----------------------------------------------------------------------------------------------------------------
 */

        System.out.println("\tReading songs from " + filename + " into jukebox...");
        while (jim.hasNextLine()) {
            String line = jim.nextLine();
            String[] musicInfo = line.split("<SEP>");
            Song music = new Song(musicInfo[2], musicInfo[3]);
                jukebox.put(music, 0);
        }
        System.out.println("\tJukebox is loaded with " + jukebox.size() + " songs");

/*
------------------------------------------------------------------------------------------------------------------
 */
        ArrayList<Song> songList = new ArrayList<>(this.jukebox.keySet());
        System.out.println("\tFirst song in jukebox: " + songList.getFirst());
        System.out.println("\tLast song in jukebox: " + songList.getLast());
    }

    /**
     * simulates the game
     *
     * @param juke Arnold class the simulation uses
     */
    public static void simulate(Arnolds juke) {
        ArrayList<Song> songList = new ArrayList<>(juke.jukebox.keySet());
        HashSet<Song> songHash = new HashSet<>();
        int currentSimulation = 1;
        int songsPlayed = 0;
        ArrayList<Song> firstFiveSongs = new ArrayList<>();

/*
-----------------------------------------------------------------------------------------------------------
 */
        long startTime = System.currentTimeMillis();
        while (currentSimulation <= juke.MAX_RUNS) {
            Song s = songList.get(rng.nextInt(0 ,  songList.size()));
            if (songsPlayed < 5 && !songHash.contains(s)) {
                firstFiveSongs.add(s);
                songsPlayed++;
            }
            if (songHash.contains(s)) {
                for (Song song : songHash) {
                    juke.jukebox.put(song, juke.jukebox.get(song) + 1);
                }
                songHash.clear();
                currentSimulation++;
            } else {
                songHash.add(s);
            }
        }
        long endTime = System.currentTimeMillis();

/*
----------------------------------------------------------------------------------------------------------------
 */
        System.out.println("Running the simulation.  The jukebox starts rockin'!");
        System.out.println("\tPrinting first 5 songs played...");
        for (Song s : firstFiveSongs) {
            System.out.println("\t\t" + s);
        }
        System.out.println("\tSimulation took " + ((endTime - startTime)/1000) + " second/s to run");
    }

    /**
     * displays number of simulations, number of songs played, and the average songs to get a duplicate
     * @param juke Arnold class used for simulation
     */
    public static void totalSongsPlayed(Arnolds juke) {
        int total_plays = 0;
        Song mostPlayedSong = null;
        for (Song s : juke.jukebox.keySet()) {
            if (mostPlayedSong == null || juke.jukebox.get(s) > juke.jukebox.get(mostPlayedSong)) {
                mostPlayedSong = s;
            }
            total_plays += juke.jukebox.get(s);
        }
        System.out.println("\tNumber of simulations run: " + juke.MAX_RUNS);
        System.out.println("\tTotal number of songs played: " + total_plays);
        System.out.println("\tAverage number of songs played per simulation to get duplicate: " + (int) ceil((double) total_plays/juke.MAX_RUNS));
        bestSong(juke, mostPlayedSong);
    }

    /**
     * displays most played song and all songs by that same artist
     * @param juke Arnold class the simulation uses
     * @param mostPlayedSong most played song in simulation
     */
    public static void bestSong(Arnolds juke, Song mostPlayedSong) {
        TreeSet<Song> topArtist = new TreeSet<>();
        for (Song s : juke.jukebox.keySet()) {
            if (mostPlayedSong.getArtist().equals(s.getArtist())) {
                topArtist.add(s);
            }
        }
/*
-------------------------------------------------------------------------------------------------------
 */
        HashMap<String, Integer> artistPlays = new HashMap<>();
        for (Song s : juke.jukebox.keySet()) {
            if (artistPlays.containsKey(s.getArtist())) {
                artistPlays.put(s.getArtist(), artistPlays.get(s.getArtist()) + juke.jukebox.get(s));
            } else {
                artistPlays.put(s.getArtist(), juke.jukebox.get(s));
            }
        }
/*
------------------------------------------------------------------------------------------------------------
 */
        System.out.println("\tMost played song: \"" + mostPlayedSong.getTitle() + "\" by \"" + mostPlayedSong.getArtist() + "\"");
        System.out.println("\tAll songs alphabetically by \"" + mostPlayedSong.getArtist() + "\":");
        for (Song s : topArtist) {
            System.out.println("\t\t\"" + s.getTitle() + "\" with " + juke.jukebox.get(s) + " plays");
        }
        mostPlayedArtist(artistPlays);
    }

    /**
     * displays most played artist with the total amount of times their songs were played
     * @param artistPlays HashMap of artists and the amount of times their songs were played
     */
    public static void mostPlayedArtist(HashMap<String, Integer> artistPlays) {
        String highestPlays = null;
        for (String s : artistPlays.keySet()) {
            if (highestPlays == null || artistPlays.get(s) > artistPlays.get(highestPlays)) {
                highestPlays = s;
            }
        }
        System.out.println("\tMost played artist: \"" + highestPlays + "\" with " + artistPlays.get(highestPlays) + " plays");
    }

    /**
     * main function of the Arnolds class
     * runs all the simulations and displays all outputs
     *
     * @param args input from command line (filename)
     * @throws FileNotFoundException if file can't be found
     */
    public static void main(String[] args) throws FileNotFoundException {
        if (args.length != 1) {
            System.out.println("Usage: java Arnolds filename");
        }
        Arnolds juke = new Arnolds(args[0]);
        simulate(juke);
        System.out.println("Displaying simulation statistics:");
        totalSongsPlayed(juke);
    }
}
