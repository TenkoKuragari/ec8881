package toys;

/**
 * flying class used for flying type toys
 *
 * @author Ethan Chen
 */
public abstract class Flying extends Toy {
    public final double MAX_ALTITUDE;
    public double currentAltitude = 0;

    /**
     * creates a flying toy
     *
     * @param productCode code of the toy
     * @param name name of the toy
     * @param maxAltitude highest the toy can go
     */
    protected Flying(int productCode, String name, double maxAltitude) {
        super(productCode, name);
        this.MAX_ALTITUDE = maxAltitude;
    }

    /**
     * increases the toy current altitude
     *
     * @param amount increase amount
     */
    public void fly(double amount) {
        this.currentAltitude += amount;
    }

    /**
     * gets the toy's current altitude
     *
     * @return current altitude
     */
    public double getCurrentAltitude() {
        return this.currentAltitude;
    }

    /**
     * gets the toy's max altitude
     *
     * @return max altitude
     */
    public double getMaxAltitude() {
        return this.MAX_ALTITUDE;
    }

    /**
     * sets up the children's special play method
     *
     * @param time time played
     */
    protected abstract void specialPlay(int time);

    /**
     * fly class's to string method
     * @return class's specific string
     */
    @Override
    public String toString() {
        return super.toString() +
                ", Flying{MA:" + this.MAX_ALTITUDE +
                ", CA:" + this.currentAltitude + "}";
    }
}
