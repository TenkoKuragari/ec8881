package toys;

/**
 * creates playdough based off toy class
 *
 * @author Ethan Chen
 */
public class PlayDough extends Toy {
    public static final double WEAR_MULTIPLIER = 0.05;

    private static int code = 100;
    private Color color;

    /**
     * makes new play dough
     *
     * @param name name of toy
     * @param color color of toy
     */
    protected PlayDough(String name, Color color) {
        super(code++, name);
        this.color = color;
    }

    /**
     * gets the color of play dough
     *
     * @return color of play dough
     */
    public Color getColor() {
        return this.color;
    }

    /**
     * play dough's specific play method
     *
     * @param time time of play
     */
    @Override
    protected void specialPlay(int time) {
        System.out.println("\tArts and crafting with " + this.color + " " + this.getName());
        this.increaseWear(WEAR_MULTIPLIER * time);
    }

    /**
     * play dough's specific to string method
     *
     * @return play dough's string output
     */
    @Override
    public String toString() {
        return super.toString() +
                ", PlayDough{C:" + this.color + "}";
    }
}
