package toys;

/**
 * public interface for the project
 *
 * @author Ethan Chen
 */
public interface IToy {
    int getProductCode();
    String getName();
    int getHappiness();
    boolean isRetired();
    double getWear();
    void increaseWear(double amount);
    void play(int time);
}