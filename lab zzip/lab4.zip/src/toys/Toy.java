package toys;

/**
 * creates a new toy, will be the parent of every toy made
 *
 * @author Ethan Chen
 */
public abstract class Toy implements IToy {
    public final static int INITIAL_HAPPINESS = 0;
    public final static int MAX_HAPPINESS = 100;
    public final static double INITIAL_WEAR = 0.0;

    private int productCode;
    private String name;
    private int happiness = INITIAL_HAPPINESS;
    private double wear = INITIAL_WEAR;

    /**
     * makes a new toy
     *
     * @param productCode code # of toy
     * @param name name of toy
     */
    protected Toy(int productCode, String name) {
        this.productCode = productCode;
        this.name = name;
    }

    /**
     * gets the code # of toy
     *
     * @return toy's code #
     */
    public int getProductCode() {
        return this.productCode;
    }

    /**
     * gets the name of toy
     *
     * @return name of toy
     */
    public String getName() {
        return this.name;
    }

    /**
     * gets happiness of toy
     *
     * @return happiness of toy
     */
    public int getHappiness() {
        return this.happiness;
    }

    /**
     * checks if toy is retired
     *
     * @return if toy is retired (t/f)
     */
    public boolean isRetired() {
        return this.happiness >= MAX_HAPPINESS;
    }

    /**
     * gets the wear on the toy
     *
     * @return toy's wear value
     */
    public double getWear() {
        return this.wear;
    }

    /**
     * increases the toy's wear amount
     *
     * @param amount amount of wear to increase by
     */
    public void increaseWear(double amount) {
        this.wear += amount;
    }

    /**
     * the method to play with the toys
     *
     * @param time time played
     */
    public void play(int time) {
        System.out.println("PLAYING(" + time + "): " + this);
        specialPlay(time);
        this.happiness += time;
        if (isRetired()) {
            System.out.println("RETIRED: " + this);
        }
    }

    /**
     * creates the special play method for each toy
     *
     * @param time time played
     */
    protected abstract void specialPlay(int time);

    /**
     * toy's to string method, base for every other to string method
     *
     * @return toy's string output
     */
    @Override
    public String toString() {
        return "Toy{PC:" + this.productCode +
                ", N:" + this.name +
                ", H:" + this.happiness +
                ", R:" + this.isRetired() +
                ", W:" + this.wear +
                "}";
    }
}
