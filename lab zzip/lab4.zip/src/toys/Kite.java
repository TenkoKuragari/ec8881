package toys;

/**
 * creates a kite based off the fly class
 *
 * @author Ethan Chen
 */
public class Kite extends Flying {

    /**
     * the different types of kites there can be
     */
    public enum Type {
        CELLULAR,
        DELTA,
        DIAMOND,
        PARAFOIL,
        ROKKAKUS,
        SLED,
        STUNT
    }

    public final double ALTITUDE_CHANGE_RATE = 0.5;
    private final double WEAR_MULTIPLIER = .05;
    private final int LINE_LENGTH;

    private static int code = 400;
    private Color color;
    private Type type;

    /**
     * creates a kite based off the fly class
     *
     * @param name name of toy
     * @param color color of toy
     * @param type type of kite
     * @param lineLength length of line
     */
    protected Kite(String name, Color color, Type type, int lineLength) {
        super(code++, name, lineLength);
        this.LINE_LENGTH = lineLength;
        this.color = color;
        this.type = type;
    }

    /**
     * gets the kite's color
     *
     * @return color of kite
     */
    public Color getColor() {
        return this.color;
    }

    /**
     * gets the type of kite
     *
     * @return kite's type
     */
    public Type getType() {
        return this.type;
    }

    /**
     * gets the length of the line
     *
     * @return kite's line length
     */
    public double getLineLength() {
        return this.LINE_LENGTH;
    }

    /**
     * kite's specific play method
     *
     * @param time time played
     */
    @Override
    protected void specialPlay(int time) {
        if (currentAltitude == 0) {
            System.out.println("\t" + this.getName() + " took off!");
        }
        this.fly(time * ALTITUDE_CHANGE_RATE);
        if (this.currentAltitude >= MAX_ALTITUDE) {
            this.currentAltitude = MAX_ALTITUDE;
        }
        System.out.println("\t" + this.getName() +  " current altitude: " + this.getCurrentAltitude() + " feet");
        this.increaseWear(time * WEAR_MULTIPLIER);
        System.out.println("\t" + "Flying the " + this.color + ", " + this.type + " kite " + this.getName() + " with " + this.LINE_LENGTH + " feets of line");
    }

    /**
     * kite's to string method
     *
     * @return kite's string output
     */
    @Override
    public String toString() {
        return super.toString() +
                ", Kite{C:" + this.color +
                ", T:" + this.type +
                ", LL:" + this.LINE_LENGTH + "}";
    }
}
