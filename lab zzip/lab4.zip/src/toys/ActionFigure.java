package toys;

/**
 * creates an action figure based off the doll class
 *
 * @author Ethan Chen
 */
public class ActionFigure extends Doll {
    public static final int MIN_ENERGY_LEVEL = 1;
    private int energyLevel = MIN_ENERGY_LEVEL;
    public final static Color HAIR_COLOR = Color.ORANGE;
    private static int code = 500;

    /**
     * creates an action figure
     *
     * @param name name of toy
     * @param age age of toy
     * @param speak catchphrase
     */
    protected ActionFigure(String name, int age, String speak) {
        super(code++, name, HAIR_COLOR, age, speak);
    }

    /**
     * gets the energy level of the toy
     *
     * @return energy level
     */
    public int getEnergyLevel() {
        return this.energyLevel;
    }

    /**
     * special play methods for an action figure
     * prints special action, adds to energy, calls doll's special playtime
     *
     * @param time amount of time played
     */
    @Override
    protected void specialPlay(int time) {
        System.out.println("\t" + this.getName() + " kung foo chops with " + this.energyLevel * time + " energy!");
        this.energyLevel++;
        super.specialPlay(time);
    }

    /**
     * the toString method for the action figure class
     *
     * @return string for action figure class
     */
    @Override
    public String toString() {
        return super.toString() +
                ", ActionFigure{E:" + this.energyLevel + "}";
    }
}
