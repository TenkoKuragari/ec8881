package toys;

/**
 * creates a plane off of flying class
 *
 * @author Ethan Chen
 */
public class RCPlane extends Flying {
    public final double MAXIMUM_SPEED;
    private final double STARTING_SPEED = 15.0;
    private final double ALTITUDE_CHANGE_RATE = 5.0;
    private final double SPEED_CHANGE_RATE = 2.0;

    private static int code = 300;
    private double currentSpeed = STARTING_SPEED;

    /**
     * creates a new rc plane
     *
     * @param name name of toy
     * @param maxSpeed max speed of rc plane
     * @param maxAltitude max altitude of toy
     */
    protected RCPlane(String name, double maxSpeed, double maxAltitude) {
        super(code++, name, maxAltitude);
        this.MAXIMUM_SPEED = maxSpeed;
    }

    /**
     * gets the current speed of toy
     *
     * @return current speed of toy
     */
    public double getSpeed() {
        return this.currentSpeed;
    }

    /**
     * gets the max speed of toy
     *
     * @return max speed of toy
     */
    public double getMaxSpeed() {
        return this.MAXIMUM_SPEED;
    }

    /**
     * rc planes specific play method
     *
     * @param time time played
     */
    @Override
    protected void specialPlay(int time) {
        if (currentAltitude == 0) {
            System.out.println("\t" + this.getName() + " took off!");
        }
        this.fly(time * ALTITUDE_CHANGE_RATE);
        if (this.currentAltitude >= MAX_ALTITUDE) {
            this.currentAltitude = MAX_ALTITUDE;
        }
        System.out.println("\t" + this.getName() +  " current altitude: " + this.getCurrentAltitude() + " feet");
        this.increaseWear(this.currentSpeed);
        this.currentSpeed += time * SPEED_CHANGE_RATE;
        if (this.currentSpeed >= MAXIMUM_SPEED) {
            this.currentSpeed = MAXIMUM_SPEED;
        }
        System.out.println("\t" + this.getName() + " current speed: " + this.currentSpeed + " mph");
    }

    /**
     * rc plane's specific to string method
     *
     * @return rc plane's string output
     */
    @Override
    public String toString() {
        return super.toString() +
                ", RCPlane{S:" + this.currentSpeed + "}";
    }
}
