package toys;

/**
 * creates a doll from the toy class
 *
 * @author Ethan Chen
 */
public class Doll extends Toy {
    private Color hairColor;
    private int age;
    private String speak;
    private static int code = 200;

    /**
     * creates a new doll
     *
     * @param name name of doll
     * @param hairColor dolls hair color
     * @param age dolls age
     * @param speak dolls catchphrase
     */
    protected Doll(String name, Color hairColor, int age, String speak) {
        this(code++, name, hairColor, age, speak);
    }

    /**
     * creates a new doll
     *
     * @param productCode dolls product code
     * @param name dolls name
     * @param hairColor dolls hair color
     * @param age dolls age
     * @param speak dolls catchphrase
     */
    protected Doll(int productCode, String name, Color hairColor, int age, String speak) {
        super(productCode, name);
        this.hairColor = hairColor;
        this.age = age;
        this.speak = speak;
    }

    /**
     * return dolls hair color
     *
     * @return dolls hair color
     */
    public Color getHairColor() {
        return this.hairColor;
    }

    /**
     * returns dolls age
     *
     * @return dolls age
     */
    public int getAge() {
        return this.age;
    }

    /**
     * returns dolls special catchphrase
     *
     * @return dolls catchphrase
     */
    public String getSpeak() {
        return this.speak;
    }

    /**
     * dolls special play actions
     *
     * @param time time played with
     */
    @Override
    protected void specialPlay(int time) {
        super.increaseWear(this.age);
        System.out.println("\t" + this.getName() + " brushes their " + this.hairColor +
                " hair and says, \"" + this.speak + "\"");
    }

    /**
     * this specific class's toString method
     *
     * @return this class's string
     */
    @Override
    public String toString() {
        return super.toString() +
                ", Doll{" +
                "HC:" + this.hairColor +
                ", A:" + this.age +
                ", S:" + this.speak +
                "}";
    }
}
