package war;

import java.util.ArrayList;
import java.util.Random;

public class Pile {
    private final ArrayList<Card> cards;
    private final String name;
    private static Random rng;

    public Pile(ArrayList<Card> cards, String name) {
        this.cards = cards;
        this.name = name;
    }

    public void addCard(Card card) {
        // TODO
    }

    public void clear() {
        // TODO
    }

    public Card drawCard(boolean faceUp) {
        // TODO
    }

    public ArrayList<Card> getCards() {
        // TODO
    }

    public boolean hasCard() {
        // TODO
    }

    public static void setSeed(long seed) {
        // TODO
    }

    public void shuffle() {
        // TODO
    }

    public String toString() {
        // TODO
    }
}
