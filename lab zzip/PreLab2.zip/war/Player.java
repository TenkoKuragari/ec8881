package war;

/**
 *
 */

public class Player {

    private final Pile pile;
    private boolean winner;


    public Player (int id) {
        // TODO
    }

    public void addCard(Card card) {
        // TODO
    }

    public void addCards(Pile cards) {
        // TODO
    }

    private Card drawCard() {
        // TODO
    }

    public boolean hasCard() {
        // TODO
    }

    public boolean isWinner() {
        // TODO
    }

    public void setWinner() {
        // TODO
    }

    @Override
    public String toString() {
        // TODO
    }
}
