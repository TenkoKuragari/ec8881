package hotpotato;

/**
 * Represents a single player in the game.
 *
 * @author Ethan Chen
 */

public class Player {
    private final String name;
    private final int id;

    /**
     * Create a new player
     *
     * @param name will be the name of the player
     * @param id will be the id of the player
     */
    public Player(String name, int id) {
        this.name = name;
        this.id = id;
    }

    /**
     * Accessor for player's name
     *
     * @return the player's name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Accessor for player's id
     *
     * @return the player's id
     */
    public int getId() {
        return this.id;
    }

    /**
     * Two players are equal if they have the same name and id.
     *
     * @param other the thing you want to compare
     * @return whether the comparison was true or not
     */
    @Override
    public boolean equals(Object other) {
        if (other instanceof Player) {
            Player playerX = (Player) other;
            return this.name.equals(playerX.name) &&
                    this.id == playerX.id;
        }
        return false;
    }

    /**
     * Returns a string in the form: "{Player name}({id})"
     *
     * @return the string in the right format
     */
    @Override
    public String toString() {
        return this.name + "(" + this.id + ")";
    }
}
